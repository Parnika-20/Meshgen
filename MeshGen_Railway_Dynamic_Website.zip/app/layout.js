import './globals.css'

export const metadata = {
  title: 'MeshGen',
  description: 'Where Innovation meets Intelligence'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
