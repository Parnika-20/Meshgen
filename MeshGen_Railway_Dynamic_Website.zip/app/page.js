import ContactForm from '../components/ContactForm'
import InternshipForm from '../components/InternshipForm'

export default function Home(){

return(
<main>

<section className="hero">
<h1>Mesh<span>Gen</span></h1>
<p>Where Innovation meets Intelligence</p>
<a className="btn" href="#forms">Explore Platform</a>
</section>

<section className="container">

<div className="grid">

<div className="card">
<h2>AI & Generative AI</h2>
<p>Enterprise AI systems, RAG architecture and intelligent automation.</p>
</div>

<div className="card">
<h2>Cloud Engineering</h2>
<p>Cloud-native modernization and scalable infrastructure.</p>
</div>

<div className="card">
<h2>Cybersecurity</h2>
<p>Secure architecture, DevSecOps and enterprise protection.</p>
</div>

</div>

</section>

<section id="forms" className="container">

<div className="grid">

<ContactForm />

<InternshipForm />

<div className="card">
<h2>Dynamic Platform</h2>
<p>
• Firebase database integration<br/>
• Railway deployment ready<br/>
• Dynamic forms<br/>
• Real backend architecture
</p>
</div>

</div>

</section>

<footer className="footer">
<h3>MeshGen</h3>
<p>Where Innovation meets Intelligence</p>
<p>contact@meshgen.in</p>
</footer>

</main>
)
}
